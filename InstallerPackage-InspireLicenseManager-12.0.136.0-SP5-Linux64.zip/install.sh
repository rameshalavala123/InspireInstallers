#!/bin/sh

distro=''
prefix=''
lic_pkg=''
rpm_opts='-vh'
silent_install=''

if [ "$BASH_VERSION" != '' ]; then
   is_bash=true
elif [ -x /bin/bash ]; then
   exec /bin/bash "$0" "$@"
else
   is_bash=false
fi

cd "`dirname "$0"`"

package_name='Inspire-License-Manager'
inspiredesigner_pkg="`echo Inspire-License-Manager-Linux*.rpm`"
hasp_pkg="`echo aksusbd-*.rpm`"
sw_lic_pkg='Inspire-Designer-SW-Lic-1.0-0.noarch.rpm'
default_prefix='/opt/Quadient'
preselect_lic_method=no
wizard="config-wizard.sh"

print_help()
   {
   echo "Usage:"
   echo "$0 [--prefix=INSTALL_PREFIX] [--non-root-installation] [--silent-installation=CONFIG_FILE]"
   echo "Note: --silent-installation override --prefix settings"
   }

parse_parameters()
   {
   while [ $# -gt 0 ]; do
      case "$1" in
         --prefix)
            prefix="$2"
            shift
            ;;
         --prefix=*)
            prefix="${1#*=}"
            ;;
         --non-root-installation)
            non_root_installation
            exit 0
            ;;
         --silent-installation)
            silent_install="$2"
            shift
            ;;
         --silent-installation=*)
            silent_install="${1#*=}"
            ;;
         *)
            print_help
            exit 0
            ;;
      esac
      shift
   done
   if [ -n "$silent_install" ]; then unset prefix; fi
   }

user_answered_yes()
   {
   while : ; do
      read answer
      case "$answer" in
         Y|y|[Yy][Ee][Ss])
            return 0
            ;;
         N|n|[Nn][Oo])
            return 1
            ;;
      esac
      echo 'Answer yes or no.'
   done
   }

non_root_installation()
   {
   if [ ! -w . ]; then
      echo 'Current directory is not writable. Copy installation files to another location.'
      exit 1
   fi
   dest_dir=${prefix:-.}
   force_select_dir=false
   if [ "$prefix" = '' ]; then
      printf 'Do you want to extract Inspire Designer to current directory? [yes/no] '
   elif [ ! -w "$prefix" ]; then
      echo "Directory '$prefix' specified with parameter --prefix is not writable."
      echo "Select another directory."
      force_select_dir=true
   else
      printf "Do you want to extract Inspire Designer to '%s'? [yes/no] " "$dest_dir"
   fi
   if [ $force_select_dir = true ] || ! user_answered_yes; then
      echo 'Subdirectory with Inspire Designer will be extracted to destination directory.'
      while : ; do
         printf 'Select destination directory: '
         if [ $is_bash = true ]; then
            read -e dest_dir
         else
            read dest_dir
         fi
         if [ ! -d "$dest_dir" ]; then
            echo "Directory '$dest_dir' does not exist!"
            continue
         elif [ ! -w "$dest_dir" ]; then
            echo "Directory '$dest_dir' is not writable!"
            continue
         else
            break
         fi
      done
   fi
   rpm2cpio /dev/null 2>/dev/null
   if [ $? -eq 127 ]; then
      echo "Command rpm2cpio is missing. Install it or add directory with this command to '$PATH'."
      exit 2
   fi
   if ! rpm2cpio "$inspiredesigner_pkg" | cpio -idm ; then
      echo 'Extraction failed. Contact support.'
      exit 3
   fi
   find opt/Quadient -type d -print0 | xargs -0 chmod a+rx
   if ! mv opt/Quadient/* "$dest_dir/"; then
      echo 'Cannot move Inspire Designer from current directory to destination directory.'
      exit 4
   fi
   rmdir -p opt/Quadient
   echo "Inspire Designer was successfully installed to '$dest_dir'."
   exit 0
   }

check_files()
   {
   for file in "$inspiredesigner_pkg" "$sw_lic_pkg"; do
      if [ ! -e "$file" ]; then
         echo "Cannot find package $file - check installation archive!"
         exit 1
      fi
   done
   }

guess_distribution()
   {
   if [ -e /etc/SuSE-release ]; then
      distro="suse"
   elif [ -e /etc/redhat-release ]; then
      distro="redhat"
   elif [ -e /etc/centos-release ]; then
      distro="centos"
   fi
   }

guess_prefix()
   {
   [ "$prefix" != '' ] && return
   prefix="$default_prefix"
   package=`rpm -qa --last | grep "^$package_name" | cut -d' ' -f1 | head -n 1`
   if [ "$package" != '' ]; then
      path=`rpm -ql "$package" | grep '\(InspireLicenseManager\.bin\|InspireCLI\.bin\)$' | sed 's#/[^/]*/[^/]*$##'`
      if [ "$path" != '' ]; then
         prefix="$path"
      fi
   fi
   echo "Select installation prefix [$prefix]: "
   if [ $is_bash = true ]; then
      read -e new_prefix
   else
      read new_prefix
   fi
   if [ "$new_prefix" != '' ]; then
      prefix="$new_prefix"
   fi
   }

check_usb_for_hasp()
   {
   [ -e /proc/bus/usb/devices -o -e /sys/bus/usb/devices ] && return
   ( mount | grep '/proc/bus/usb' > /dev/null ) && return
   usbfs="`cut -f2 /proc/filesystems | grep ^usb`"
   if [ "$usbfs" = '' ]; then
      echo "Your kernel supports neither usbfs nor usbdevfs filesystem."
      echo "Hardware dongle driver could not work properly."
      exit 3
   fi
   cat << !FSTAB!
USB device filesystem is not mounted. Hardware dongle driver requires it.
Add this line to your /etc/fstab:
$usbfs   /proc/bus/usb  $usbfs   defaults    0 0
and mount /proc/bus/usb
!FSTAB!
   exit 3
   }

check_32bit_libc()
   {
   if [ ! -e /lib/libc.so.6 -a ! -e /lib/i386-linux-gnu/libc.so.6 ]; then
      echo "Cannot find 32-bit libraries on this system."
      echo "Installation of hardware dongle driver will probably fail."
      case "$distro" in
         redhat|centos)
            echo "Install required libraries with command: yum install glibc.i686"
            echo "and rerun installation."
            ;;
         suse)
            echo "Install required libraries with command: zypper install glibc-32bit"
            echo "and rerun installation."
            ;;
      esac
   fi
   }

check_sw_lic()
   {
   licpkg=`rpm -qa | grep '\<SW-Lic\>'`
   if [ "$licpkg" = '' ]; then
      return 1
   fi
   rpm -q --provides "$licpkg" 2> /dev/null | grep aksusbd > /dev/null
   }

select_hasp()
   {
   [ -x "/usr/sbin/aksusbd" ] || check_sw_lic && return
   if [ "$preselect_lic_method" = yes ]; then
      lic_pkg="$sw_lic_pkg"
      return
   fi
   default_lic=2
   while : ; do
      cat << !MENU1!
License type:
 1. Hardware dongle - drivers for Red Hat/SuSE
 2. NetLicense
Choice (q=quit) [$default_lic]:
!MENU1!
      read answer
      if [ "$answer" = '' ]; then
         answer=$default_lic
      fi
      case "$answer" in
         1)
            lic_pkg="$hasp_pkg"
            check_32bit_libc
            check_usb_for_hasp
            ;;
         2)
            lic_pkg="$sw_lic_pkg"
            ;;
         q|Q|quit|Quit)
            exit 0
            ;;
         *)
            continue
            ;;
      esac
      break
   done
   }

confirm_installation()
   {
   cat << !LOG!
Following packages will be $installed_or_upgraded:
$inspiredesigner_pkg (into directory $prefix)
$lic_pkg
!LOG!
   printf "Do you want to continue? [Y/n] "
   read answer
   if [ "$answer" != '' -a "$answer" != 'Y' -a "$answer" != 'y' ]; then
      exit 0
   fi
   }

confirm_eula()
   {
   ${PAGER:-more} EULA.txt
   echo
   printf "Do you accept this license agreement? [y/n] "
   read answer
   case "$answer" in
      y|Y|yes|Yes|YES)
      ;;
      *)
      echo "You must accept this license agreement to proceed with installation."
      exit 1
      ;;
   esac
   }

launch_wizard()
   {
   if [ -z "$silent_install" ]; then
      printf "\nDo you want launch config-wizard script to setup licensation & daemons? [Y/n] "
      read answer
      case "$answer" in
         [nN]|[nN][oO])
         ;;
         *)
         /bin/bash "./$wizard"
         exit $?
         ;;
      esac
   else
      echo "Silent installation finish"
      install_folder_name="$(rpm -q --queryformat "%{NAME}" -p "$inspiredesigner_pkg")"
      . "./$wizard" "--silent-configuration=$silent_install" "$prefix/$install_folder_name"
      exit $?
   fi
   }


parse_parameters "$@"
check_files

installed=false
installed_or_upgraded=installed

if rpm -qi Inspire-License-Manager > /dev/null; then
   installed=true
   installed_or_upgraded=upgraded
   lmloc=`rpm -ql Inspire-License-Manager | grep '/InspireLicenseManager$'`
   oldinstdir="${lmloc%/*}"
elif rpm -qi License-Manager > /dev/null; then
   installed=true
   installed_or_upgraded=upgraded
   lmloc=`rpm -ql License-Manager | grep '/LicenseManager$'`
   oldinstdir="${lmloc%/*}"
fi

copy_lslic()
   {
   if [ x$installed = xtrue ]; then
      instdir="$prefix/`rpm -qlp \"$inspiredesigner_pkg\" | head -n 1 | sed 's#^.*/\(\(Inspire-\)\?License-Manager-.*\)/.*$#\1#'`"
      if [ -d "$oldinstdir" -a -d "$instdir" ]; then
         if ! ( cd "$oldinstdir" && find . -type f | while read file; do fname="${file##*/}"; case "$fname" in (*LicenseManager-init.sh|*LicenseManager.service);; (*) echo "$file";; esac; done | tar c -T - ) | ( cd "$instdir" && tar x ); then
            echo "Unable to copy license from previous Inspire License Manager installation!"
            return
         fi
      fi
   fi
   }

# script body
if [ "`id -u`" != '0' ]; then
   echo "Install script must run with root privileges."
   exit 1
fi

if [ -z "$silent_install" ]; then
   confirm_eula
else
   . "$silent_install"
   if [ "$general_eulaAccepted" -ne 1 ]; then
      echo "You must accept this license agreement to proceed with installation."
      exit 100
   fi
   echo "Silent installation start"
   rpm_opts="--quiet --force"
   if [ -z "$prefix" ]; then
      prefix="$general_installationDir"
   fi
fi
guess_distribution
if [ -z "$silent_install" ]; then
   guess_prefix
   select_hasp
   confirm_installation
else
   [ -x "/usr/sbin/aksusbd" ] || check_sw_lic || rpm -i $rpm_opts "$sw_lic_pkg"
fi
if [ "$lic_pkg" != '' ]; then
   rpm -i $rpm_opts "$lic_pkg"
fi
if [ "$prefix" = '' -o "$prefix" = "$default_prefix" ]; then
   rpm -i $rpm_opts "$inspiredesigner_pkg"
   prefix="$default_prefix"
else
   rpm -i $rpm_opts "--prefix=$prefix" "$inspiredesigner_pkg"
fi
if [ -x "/bin/bash" -a -f "./$wizard" ]; then
   launch_wizard
fi

copy_lslic
